import { client, urlFor } from "../../sanity";
// 1. Import the new DynamicForm instead of the old ContactForm!
import DynamicForm from "../../components/DynamicForm"; 

export default async function About() {
  // Notice your data is saved in a variable called "sanityData" here
  const sanityData = await client.fetch(`*[_type == "page" && slug.current == "about"][0]`);

  if (!sanityData) {
    return <div style={{ padding: "50px", textAlign: "center" }}>Page not found in Sanity yet!</div>;
  }

  return (
    <main style={{ maxWidth: "800px", margin: "0 auto", padding: "50px", fontFamily: "Arial, sans-serif" }}>
      
      <h1 style={{ fontSize: "3rem", color: "#111827", marginBottom: "10px" }}>
        {sanityData.heading}
      </h1>
      
      {sanityData.mainImage && (
        <img 
          src={urlFor(sanityData.mainImage).width(800).url()} 
          alt="About Page Image"
          style={{ width: "100%", borderRadius: "10px", marginTop: "20px", marginBottom: "20px" }}
        />
      )}

      <p style={{ fontSize: "1.2rem", color: "#4B5563", lineHeight: "1.6" }}>
        {sanityData.body}
      </p>

      <div style={{ marginTop: "60px" }}>
        <h2 style={{ fontSize: "2rem", marginBottom: "20px" }}>Have Questions?</h2>
        
        {/* 2. Use DynamicForm, use "sanityData", and remove the quotes! */}
        <DynamicForm formData={sanityData?.leadForm} />
        
      </div>

    </main>
  );
}