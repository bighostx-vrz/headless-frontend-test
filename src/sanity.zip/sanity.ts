import { createClient } from "next-sanity";
import { createImageUrlBuilder } from "@sanity/image-url";

export const client = createClient({
  projectId: process.env.NEXT_PUBLIC_SANITY_PROJECT_ID,
  dataset: "testing", 
  apiVersion: "2024-01-01",
  useCdn: false,
  token: "skP0wXtlaK4faI3SHH15GattL5arITe97mDVxQpLcgstWItFTKXtmYVYcwX6eiDQDRgfJSoCnJXiCqnQWaYYUyBrqxQYpWDtclzhD3NowQkTPPmyGdWlK51EfLiCSmdpMf0fJ2DsgPTY5ls2EK1GtIyf7mAlj9wRbbJAuseUCR7M0YXQCuAS", // <--- ADD THIS VIP PASS!
  stega: {
    enabled: true, 
    studioUrl: "http://localhost:3333", 
  },
});

const builder = createImageUrlBuilder(client);
export function urlFor(source: any) {
  return builder.image(source);
}