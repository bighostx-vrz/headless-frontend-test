import Image from 'next/image'
import {PortableText} from '@portabletext/react'
import {stegaClean} from 'next-sanity'
import {urlFor} from '@/sanity/lib/image'
import DynamicForm from './DynamicForm'
import {menuHref} from './MenuRenderer'

function Widget({widget}:{widget:any}){
  if(!widget||widget.enabled===false)return null
  const type=stegaClean(widget.widgetType||'text')
  const style={textAlign:stegaClean(widget.textAlign||'left')} as const
  if(type==='heading'){const Tag=(['h2','h3','h4','p'].includes(widget.headingLevel)?widget.headingLevel:'h2') as 'h2';return <Tag className={widget.cssClass||''} style={style}>{widget.heading}</Tag>}
  if(type==='text')return <div className={widget.cssClass||''} style={style}>{Array.isArray(widget.richText)&&<PortableText value={widget.richText}/>}</div>
  if(type==='image'&&widget.image?.asset)return <Image className={widget.cssClass||''} src={urlFor(widget.image).width(1400).url()} alt={widget.alt||''} width={1400} height={900}/>
  if(type==='button')return <div style={style}><a className={`button button-${stegaClean(widget.buttonStyle||'primary')}`} href={menuHref(widget.buttonLink)}>{widget.buttonLabel||'Learn more'}</a></div>
  if(type==='stat')return <div className={`stat ${widget.cssClass||''}`} style={style}><strong>{widget.statValue}</strong><span>{widget.statLabel}</span></div>
  if(type==='feature')return <div className={`bhx-feature ${widget.cssClass||''}`} style={style}>{widget.iconText&&<div className="feature-icon">{widget.iconText}</div>}{widget.heading&&<h3>{widget.heading}</h3>}{widget.text&&<p>{widget.text}</p>}</div>
  if(type==='form'&&widget.form)return <DynamicForm form={widget.form}/>
  if(type==='linkedContent')return <div className="section-grid">{widget.linkedContent?.map((item:any,i:number)=>{const href=item._type==='post'?`/blog/${stegaClean(item.slug?.current||'')}`:item._type==='category'?`/category/${stegaClean(item.slug?.current||'')}`:item._type==='page'?(item.slug?.current==='home'?'/':`/${stegaClean(item.slug?.current||'')}`):(item.fileUrl||'#');return <a className="content-card" key={item._id||i} href={href}><div className="card-body"><span className="eyebrow">{item._type}</span><h3>{item.title}</h3>{item.excerpt&&<p>{item.excerpt}</p>}</div></a>})}</div>
  if(type==='spacer')return <div className={`bhx-spacer spacer-${stegaClean(widget.spacerSize||'medium')}`} aria-hidden="true"/>
  if(type==='divider')return <hr className="bhx-divider"/>
  if(type==='html'&&process.env.ALLOW_ADVANCED_CODE==='true')return <div dangerouslySetInnerHTML={{__html:stegaClean(widget.html||'')}}/>
  return null
}
export default function RowsColumns({rows}:{rows:any[]}){return <div className="bhx-rows">{rows?.map((row:any,ri:number)=><div id={row.anchorId||undefined} key={row._key||ri} className={`bhx-row ${row.customClass||''}`}><div className="bhx-row-grid">{row.columns?.map((col:any,ci:number)=><div key={col._key||ci} className={`bhx-column valign-${stegaClean(col.verticalAlign||'start')} pad-${stegaClean(col.padding||'none')}`} style={{'--col-d':col.widthDesktop||12,'--col-t':col.widthTablet||12,'--col-m':col.widthMobile||12,background:col.backgroundColor?.hex||undefined} as any}>{col.widgets?.map((widget:any,wi:number)=><Widget widget={widget} key={widget._key||wi}/>)}</div>)}</div></div>)}</div>}
