import {draftMode} from 'next/headers'
import type {QueryParams} from 'next-sanity'
import {client} from './client'
import {studioUrl} from '../env'

export async function sanityFetch<T>(query: string, params: QueryParams = {}): Promise<T> {
  const cookieDraftMode = (await draftMode()).isEnabled
  const alwaysPreviewDrafts = process.env.SANITY_ALWAYS_PREVIEW_DRAFTS === 'true'
  const isDraftMode = cookieDraftMode || alwaysPreviewDrafts
  const token = process.env.SANITY_API_READ_TOKEN

  if (isDraftMode && !token) {
    throw new Error('SANITY_API_READ_TOKEN is required while Draft Mode / preview-site mode is enabled.')
  }

  return client
    .withConfig({
      useCdn: !isDraftMode,
      stega: cookieDraftMode ? {enabled: true, studioUrl} : false,
    })
    .fetch<T>(query, params, {
      token: isDraftMode ? token : undefined,
      perspective: isDraftMode ? 'drafts' : 'published',
      next: {revalidate: isDraftMode ? 0 : 60},
    })
}
