import { draftMode } from 'next/headers';
import { redirect } from 'next/navigation';

export async function GET(request: Request) {
  // 1. Turn on Draft Mode
  draftMode().enable();

  // 2. Look at the URL Sanity sent us
  const { searchParams } = new URL(request.url);
  
  // 3. THE FIX: The Ultimate Catcher
  // This catches the Presentation Tool's automated links AND your manual Quick Links
  const path = searchParams.get('sanity-preview-pathname') || 
               searchParams.get('pathname') || 
               searchParams.get('slug') || 
               '/';

  // 4. Send the iframe to the correct URL!
  redirect(path);
}