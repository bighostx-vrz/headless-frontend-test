import type {ReactNode} from 'react'
export type BhxFrontendModule={
  id:string; title:string; version:string;
  blockTypes?:string[];
  renderBlock?:(block:any)=>ReactNode;
  resolveInternalLink?:(doc:any)=>string|undefined;
  getSitemapEntries?:()=>Promise<Array<{loc:string;lastmod?:string}>>;
  search?:(query:string)=>Promise<any[]>;
}
