import type {BhxFrontendModule} from './types'

// BHX_ADDON_IMPORTS
export const frontendModules: BhxFrontendModule[] = [

  // BHX_ADDON_ENTRIES
]
